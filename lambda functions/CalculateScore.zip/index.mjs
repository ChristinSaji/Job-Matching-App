import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import {
  TextractClient, AnalyzeDocumentCommand,
} from "@aws-sdk/client-textract";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient, PutCommand, GetCommand,
} from "@aws-sdk/lib-dynamodb";
import { v4 as uuidv4 } from "uuid";

const s3Client = new S3Client({});
const textractClient = new TextractClient({});
const ddbClient = new DynamoDBClient({});
const ddbDocClient = DynamoDBDocumentClient.from(ddbClient);

const BUCKET_NAME = process.env.BUCKET_NAME;
const APPLICATIONS_TABLE = process.env.APPLICATIONS_TABLE;
const EXTRACTED_TEXT_TABLE = process.env.EXTRACTED_TEXT_TABLE;

const stopWords = new Set([
  "i", "me", "my", "myself", "we", "our", "ours", "ourselves", "you", "your", 
  "yours", "yourself", "yourselves", "he", "him", "his", "himself", "she", 
  "her", "hers", "herself", "it", "its", "itself", "they", "them", "their", 
  "theirs", "themselves", "what", "which", "who", "whom", "this", "that", 
  "these", "those", "am", "is", "are", "was", "were", "be", "been", "being", 
  "have", "has", "had", "having", "do", "does", "did", "doing", "a", "an", 
  "the", "and", "but", "if", "or", "because", "as", "until", "while", "of", 
  "at", "by", "for", "with", "about", "against", "between", "into", "through", 
  "during", "before", "after", "above", "below", "to", "from", "up", "down", 
  "in", "out", "on", "off", "over", "under", "again", "further", "then", 
  "once", "here", "there", "when", "where", "why", "how", "all", "any", 
  "both", "each", "few", "more", "most", "other", "some", "such", "no", "nor", 
  "not", "only", "own", "same", "so", "than", "too", "very", "s", "t", "can", 
  "will", "just", "don", "should", "now",
]);

export const handler = async (event) => {
  try {
    const { companyName, jobTitle, jobDescription, resume } = JSON.parse(
      event.body
    );
    const userId = event.requestContext.authorizer.claims.sub;

    const applicationId = uuidv4();
    const timestamp = new Date().toISOString();

    if (!resume.content) {
      throw new Error("Resume content is undefined");
    }

    // Upload resume to S3
    const resumeBuffer = Buffer.from(resume.content, "base64");
    const resumeKey = `resumes/${applicationId}/${resume.filename}`;
    const putObjectParams = {
      Bucket: BUCKET_NAME,
      Key: resumeKey,
      Body: resumeBuffer,
      ContentType: resume.contentType,
    };

    await s3Client.send(new PutObjectCommand(putObjectParams));

    // Extract text from the resume using Textract
    const textractParams = {
      Document: {
        S3Object: {
          Bucket: BUCKET_NAME,
          Name: resumeKey,
        },
      },
      FeatureTypes: ["TABLES", "FORMS"],
    };
    const textractResponse = await textractClient.send(
      new AnalyzeDocumentCommand(textractParams)
    );
    const blocks = textractResponse.Blocks;

    // Collect extracted text from Textract response
    let extractedText = "";
    blocks.forEach((block) => {
      if (block.BlockType === "WORD") {
        extractedText += block.Text + " ";
      }
    });

    // Store extracted text in DynamoDB
    const putExtractedTextParams = {
      TableName: EXTRACTED_TEXT_TABLE,
      Item: {
        applicationId,
        extractedText,
        timestamp,
      },
    };
    await ddbDocClient.send(new PutCommand(putExtractedTextParams));

    // Retrieve the verified extracted text
    const extractedTextResult = await ddbDocClient.send(
      new GetCommand({
        TableName: EXTRACTED_TEXT_TABLE,
        Key: { applicationId },
      })
    );

    const verifiedExtractedText = extractedTextResult.Item?.extractedText || "";

    // Tokenize text by removing stop words
    const tokenize = (text) =>
      text
        .toLowerCase()
        .split(/\W+/)
        .filter((word) => !stopWords.has(word) && word.length > 0);

    const resumeWords = tokenize(verifiedExtractedText);
    const jobWords = tokenize(jobDescription);

    if (jobWords.length === 0) {
      throw new Error("Job description contains no valid words");
    }

    // Calculate matching score
    const wordSet = new Set(jobWords);
    const matchingWords = new Set(resumeWords.filter((word) => wordSet.has(word)));
    const score = ((matchingWords.size / wordSet.size) * 100).toFixed(2);

    // Store application details and matching score in DynamoDB
    const putCommandParams = {
      TableName: APPLICATIONS_TABLE,
      Item: {
        userId,
        applicationId,
        companyName,
        jobTitle,
        jobDescription,
        resumeKey,
        matchingScore: parseFloat(score),
        timestamp,
      },
    };

    await ddbDocClient.send(new PutCommand(putCommandParams));

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "POST,OPTIONS",
      },
      body: JSON.stringify({
        message: "Application submitted successfully",
        matchingScore: parseFloat(score),
      }),
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "POST,OPTIONS",
      },
      body: JSON.stringify({ message: "Failed to submit application", error }),
    };
  }
};
