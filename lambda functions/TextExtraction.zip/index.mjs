import {
  TextractClient,
  AnalyzeDocumentCommand,
} from "@aws-sdk/client-textract";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand } from "@aws-sdk/lib-dynamodb";

const textractClient = new TextractClient({});
const ddbClient = new DynamoDBClient({});
const ddbDocClient = DynamoDBDocumentClient.from(ddbClient);

const EXTRACTED_TEXT_TABLE = process.env.EXTRACTED_TEXT_TABLE;

export const handler = async (event) => {
  try {
    const { Records } = event;
    for (const record of Records) {
      const { s3 } = record;
      const bucket = s3.bucket.name;
      const key = decodeURIComponent(s3.object.key.replace(/\+/g, " "));

      const textractParams = {
        Document: {
          S3Object: {
            Bucket: bucket,
            Name: key,
          },
        },
        FeatureTypes: ["TABLES", "FORMS"],
      };
      const textractResponse = await textractClient.send(
        new AnalyzeDocumentCommand(textractParams)
      );
      const blocks = textractResponse.Blocks;

      let extractedText = "";
      blocks.forEach((block) => {
        if (block.BlockType === "LINE") {
          extractedText += block.Text + "\n";
        }
      });

      const putCommandParams = {
        TableName: EXTRACTED_TEXT_TABLE,
        Item: {
          applicationId: key.split("/")[1],
          extractedText,
        },
      };
      await ddbDocClient.send(new PutCommand(putCommandParams));
    }

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Text extraction and storage successful",
      }),
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: "Text extraction and storage failed",
        error,
      }),
    };
  }
};
