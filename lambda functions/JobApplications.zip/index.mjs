import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand } from "@aws-sdk/lib-dynamodb";
import { v4 as uuidv4 } from "uuid";

const ddbClient = new DynamoDBClient({});
const ddbDocClient = DynamoDBDocumentClient.from(ddbClient);
const s3Client = new S3Client({});

const BUCKET_NAME = "job-matching-app-resumes";
const APPLICATIONS_TABLE = "JobApplications";

export const handler = async (event) => {
  try {
    const { companyName, jobTitle, jobDescription, resume } = JSON.parse(
      event.body
    );
    const userId = event.requestContext.authorizer.claims.sub;

    const applicationId = uuidv4();

    if (!resume.content) {
      throw new Error("Resume content is undefined");
    }

    const resumeBuffer = Buffer.from(resume.content, "base64");
    const resumeKey = `resumes/${applicationId}/${resume.filename}`;
    const putObjectParams = {
      Bucket: BUCKET_NAME,
      Key: resumeKey,
      Body: resumeBuffer,
      ContentType: resume.contentType,
    };

    await s3Client.send(new PutObjectCommand(putObjectParams));

    const putCommandParams = {
      TableName: APPLICATIONS_TABLE,
      Item: {
        userId,
        applicationId,
        companyName,
        jobTitle,
        jobDescription,
        resumeKey,
      },
    };

    await ddbDocClient.send(new PutCommand(putCommandParams));

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
      },
      body: JSON.stringify({
        message: "Application submitted successfully",
        applicationId,
      }),
    };
  } catch (error) {
    console.error(error);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
      },
      body: JSON.stringify({ message: "Failed to submit application", error }),
    };
  }
};
