import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, QueryCommand } from "@aws-sdk/lib-dynamodb";

const ddbClient = new DynamoDBClient({});
const ddbDocClient = DynamoDBDocumentClient.from(ddbClient);

const APPLICATIONS_TABLE = process.env.APPLICATIONS_TABLE;

export const handler = async (event) => {
  try {
    const userId = event.requestContext.authorizer.claims.sub;

    const params = {
      TableName: APPLICATIONS_TABLE,
      KeyConditionExpression: "userId = :userId",
      ExpressionAttributeValues: {
        ":userId": userId,
      },
      ScanIndexForward: false,
    };

    const data = await ddbDocClient.send(new QueryCommand(params));

    const applications = data.Items.map((item) => ({
      ...item,
      resumeFileName: item.resumeKey.split("/").pop(),
    }));

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "GET,OPTIONS",
      },
      body: JSON.stringify({
        history: applications,
      }),
    };
  } catch (error) {
    console.error("Error fetching history:", error);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "GET,OPTIONS",
      },
      body: JSON.stringify({ message: "Failed to fetch history", error }),
    };
  }
};
